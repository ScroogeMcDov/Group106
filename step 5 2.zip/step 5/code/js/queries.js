const express = require("express");
const cors = require('cors');ç
var mysql = require('./dbcon.js');
const bodyParser = require('body-parser');

const app = express();
const corsOptions = {
    origin: "http://flip3.engr.oregonstate.edu:4169",
    optionsSuccessStatus: 200
}

app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.set('mysql', mysql);

// Insert new UserAcccount into db
app.post("/UserRegistration", (req, res) => {
    let mysql = req.app.get('mysql');
    let sql = "INSERT INTO UserRegistrations (lastName, firstName, password, email, zipCode) VALUES (?, ?, ?, ?, ?)";
    let inserts = [req.body.lastName, req.body.firstName, req.body.password, req.body.email, req.body.zipCode];
    sql = mysql.pool.query(sql, inserts, function (error, results, fields) {
        let msg = ""
        if (error) {
            let msg = "incorrect info"
        } else {
            let msg = ` ${req.body.firstName}, your email is ${req.body.email} and your account is ready to use.`;
        }
        res.send({ msg });
    });
});

// Select a user from the UserAccounts table given email and password.
app.get("/UserLogin", (req, res) => {
    let mysql = req.app.get('mysql');
    let sql = "SELECT userID, lastName, firstName, email FROM UserSignUps WHERE email = ? AND password = ?";
    let data = [req.query.email, req.query.password];
    sql = mysql.pool.query(sql, data, function (error, results, fields) {
        const queryResults = {};
        if (error || results[0] == null) {
            queryResults["successful"] = false;
        } else {
            queryResults["successful"] = true;
            queryResults["userID"] = results[0].userID;
            queryResults["firstName"] = results[0].firstName;
            queryResults["lastName"] = results[0].lastName;
            queryResults["email"] = results[0].email;
        }
        res.send(queryResults);
    });
});


// Insert new Location into UserLocationsHistory:
app.post("/UserRegistration", (req, res) => {
    let mysql = req.app.get('mysql');
    let sql = "INSERT INTO UserLocationHistory VALUES (?, ?, ?)";
    let inserts = [req.body.zipCode]
    sql = mysql.pool.query(sql, inserts, function (error, results, fields) {
        let msg = ""
        if (error) {
            let msg = "incorrect info"
        } else {
            let msg = ` ${req.body.firstName}, your email is ${req.body.email} and your account is ready to use.`;
        }
        res.send({ msg });
    });
});

å
// Select specific user:
app.post("/getUser", (req, res) => {
    let mysql = req.app.get('mysql');
    let sql = "SELECT UserAccounts.userID FROM UserAccounts WHERE UserAccounts.userID = ?";
    insert = [req.body.userID]
    sql = mysql.pool.query(sql, insert, function (error, results, fields) {
        var queryResults = [];
        results.forEach((row) => {
            queryResults.push(row)
        })
        console.log(queryResults);
        res.send(queryResults);
    });
});


// Select all Guides in certain location:
app.post("/getGuides", (req, res) => {
    let mysql = req.app.get('mysql');
    let sql = "SELECT UserAccounts.isGuide FROM UserAccounts WHERE UserAccounts.locationID = ?";
    insert = [req.body.userID]
    sql = mysql.pool.query(sql, insert, function (error, results, fields) {
        var queryResults = [];
        results.forEach((row) => {
            queryResults.push(row)
        })
        console.log(queryResults);
        res.send(queryResults);
    });
});



// Delete a specific UserLocation:
app.post("/deleteUserLocation", (req, res) => {
    let mysql = req.app.get('mysql');
    let sql = "DELETE FROM UserLocationHistory WHERE UserLocationHistory.locationID = ?";
    insert = [req.body.userID]
    sql = mysql.pool.query(sql, insert, function (error, results, fields) {
        var queryResults = [];
        results.forEach((row) => {
            queryResults.push(row)
        })
        console.log(queryResults);
        res.send(queryResults);
    });
});


// // Delete a specific UserAccount:
// app.post("/deleteUserAccount", (req, res) => {
//     let mysql = req.app.get('mysql');
//     let sql = "DELETE FROM UserLogins WHERE UserLogins.lastName = ? AND UserLogins.firstName = ? AND UserLogins.password = ?;
//     insert = [req.body.userID]
//     sql = mysql.pool.query(sql, insert, function (error, results, fields) {
//         var queryResults = [];
//         results.forEach((row) => {
//             queryResults.push(row)
//         })
//         console.log(queryResults);
//         res.send(queryResults);
//     });
// });

app.set('port', process.argv[2]);

app.listen(app.get('port'), function(){
    console.log('Express started on http://localhost:' + app.get('port') 
    + '; press Ctrl-C to terminate.');}
     );

     