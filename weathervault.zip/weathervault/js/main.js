/* ====
I removed the big text from the html and put it in this module.
So put all the text here.
  ==== */


// Selectors
const textSelector = document.querySelector("#descriptions");
//
// const text1 = "The Weather Vault website is designed" +
//   " for people moving to another city in the US and concerned" +
//   " about change of climate.\n" +
//   "\n";
//
// const text2 = "The User enters a desired climate into the Weather Vault ®." +
//   " The WeatherVault and the UserVault entities are queried, then retrieve and display" +
//   " a list of all matching cities and profiles of certified guides are displayed. After the" +
//   " User selects a guide the User receives the guide’s contact information" +
//   " (email, first name, last name)."
//
// function mainTXT(selector, t1, t2) {
//   selector.innerHTML = t1 + t2
// }
//
// mainTXT(textSelector, text1, text2)


textSelector.on
